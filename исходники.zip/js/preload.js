function preload() {

    game.load.spritesheet('dude', 'assets/person.png', 50, 50);



    ///////////////// text emitter
    game.load.image('carrot', 'assets/emojis/1f0cf.png');
    game.load.image('star', 'assets/emojis/1f1e7.png');
    game.load.image('diamond', 'assets/emojis/1f1e8.png');
    ///////////////

}
